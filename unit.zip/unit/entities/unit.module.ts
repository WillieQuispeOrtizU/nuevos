import { Module } from '@nestjs/common';
import { UnitService } from './unit.service';
import { UnitController } from './unit.controller';
import { PrismaService } from 'src/prisma.service';
import { GlobalFunctions } from 'src/common/functions/global-function';
import { JwtService } from '@nestjs/jwt';
@Module({
  controllers: [UnitController],
  providers: [UnitService,PrismaService,GlobalFunctions,JwtService]
})
export class UnitModule {}
