import { Controller, Get, Post, Body, Patch, Param, Delete, Query, UseGuards, Request } from '@nestjs/common';
import { UnitService } from './unit.service';
import { CreateUnitDto } from './dto/create-unit.dto';
import { UpdateUnitDto } from './dto/update-unit.dto';
import { PaginationDto } from 'src/common/dto/pagination.dto';
import { AuthGuard } from 'src/auth/guard/auth.guard';

@Controller('unit')
export class UnitController {
  constructor(private readonly unitService: UnitService) {}

  @Post()
  async create(@Body() createUnitDto: CreateUnitDto) {
    return await this.unitService.create(createUnitDto);
  }


  @Get()
  async findAll(@Query() paginationDto: PaginationDto) {
    return await this.unitService.findAll(paginationDto);
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return await this.unitService.findOne(+id);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateUnitDto: UpdateUnitDto) {
    return await this.unitService.update(+id, updateUnitDto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    return await this.unitService.remove(+id);
  }

}
