import { IsOptional, IsString, IsBoolean, IsNumber } from "class-validator";

export class CreateUnitDto {

  @IsOptional()
  @IsString()
  name:string;    
  
  @IsOptional()
  @IsString()
  origin:string;  

  @IsOptional()
  @IsString()
  plate_number:string;  

  @IsOptional()
  @IsBoolean() 
  vehicle_fleet:boolean; 

  @IsOptional()
  @IsNumber()
  km_traveled:number;  

  @IsOptional()
  @IsString()
  year:number;  

  @IsOptional()
  @IsNumber()
  seats:number;  
      
  @IsOptional()
  entry_at: Date;
   
  @IsOptional()
  @IsNumber()
  axles:number;  
    
  @IsOptional()
  @IsString()
  brand:string;  
       
  @IsOptional()
  @IsString()
  model:string; 

  @IsOptional()
  @IsString()
  unit_serial_number:string; 

  @IsOptional()
  @IsString()
  unit_chassis_number:string; 

  @IsOptional()
  @IsString()
  engine_serial_number:string; 
       
  @IsOptional()
  @IsNumber()
  insured_seats:number; 
  
  @IsOptional()
  @IsString()
  tuc:string; 
  
  @IsOptional()
  @IsNumber()
  manufacturing_year:number; 

  @IsOptional()
  @IsString()
  chassis_number:string; 
              
  @IsOptional()
  contract_expires_at: Date;
}