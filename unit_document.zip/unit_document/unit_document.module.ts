import { Module } from '@nestjs/common';
import { UnitDocumentService } from './unit_document.service';
import { UnitDocumentController } from './unit_document.controller';
import { PrismaService } from 'src/prisma.service';
import { GlobalFunctions } from 'src/common/functions/global-function';
import { JwtService } from '@nestjs/jwt';
@Module({
  controllers: [UnitDocumentController],
  providers: [UnitDocumentService,PrismaService,GlobalFunctions,JwtService]
})
export class UnitDocumentModule {}
