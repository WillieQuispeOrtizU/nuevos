import { Controller, Get, Post, Body, Patch, Param, Delete, Query, UploadedFile, UseInterceptors, Req } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { UnitDocumentService } from './unit_document.service';
import { CreateUnitDocumentDto } from './dto/create-unit_document.dto';
import { UpdateUnitDocumentDto } from './dto/update-unit_document.dto';
import { PaginationDto } from 'src/common/dto/pagination.dto';

@Controller('unit-document')
export class UnitDocumentController {
  constructor(private readonly unitDocumentService: UnitDocumentService) {}

  @Post()
  @UseInterceptors(FileInterceptor('document'))
  async create(
    @UploadedFile() file: Express.Multer.File,
    @Body() createUnitDocumentDto: CreateUnitDocumentDto,
    @Req() req: any,
  ) {
    return this.unitDocumentService.create(createUnitDocumentDto, file, req);
  }

  @Get()
  async findAll(@Query() paginationDto: PaginationDto) {
    return this.unitDocumentService.findAll(paginationDto);
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.unitDocumentService.findOne(+id);
  }

  @Patch(':id')
  @UseInterceptors(FileInterceptor('document'))
  async update(
    @Param('id') id: string,
    @Body() updateUnitDocumentDto: UpdateUnitDocumentDto,
    @UploadedFile() file: Express.Multer.File,
    @Req() req: any,
  ) {
    return this.unitDocumentService.update(+id, updateUnitDocumentDto, file, req);
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    return this.unitDocumentService.remove(+id);
  }
}