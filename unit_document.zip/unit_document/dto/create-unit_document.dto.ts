import { IsOptional, IsString, IsBoolean, IsNumber } from "class-validator";

export class CreateUnitDocumentDto {

  @IsOptional()
  @IsString()
  description: string;

  @IsOptional()
  @IsString()
  url_document: string;

  @IsOptional()
  issued_at: Date;

  @IsOptional()
  expires_at: Date;

  @IsOptional()
  @IsBoolean()
  has_expiration: boolean;

  @IsOptional()
  @IsNumber()
  document_typeId: number;

  @IsOptional()
  @IsNumber()
  unitId: number;

}