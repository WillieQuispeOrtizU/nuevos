import { PartialType } from '@nestjs/mapped-types';
import { CreateUnitDocumentDto } from './create-unit_document.dto';

export class UpdateUnitDocumentDto extends PartialType(CreateUnitDocumentDto) {}
