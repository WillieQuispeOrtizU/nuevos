import { BadRequestException, Injectable } from '@nestjs/common';
import { CreateUnitDto } from './dto/create-unit.dto';
import { UpdateUnitDto } from './dto/update-unit.dto';
import { PrismaService } from 'src/prisma.service';
import { PaginationDto } from 'src/common/dto/pagination.dto';
import { GlobalFunctions } from 'src/common/functions/global-function';
import { ResponseScheme } from 'src/common/interfaces/response.interface';

@Injectable()
export class UnitService {

  constructor(private prisma: PrismaService, private readonly globalFunctions: GlobalFunctions) { }
  //resp scheme for returning data in response
  private resp: ResponseScheme = {
    error: false,
    message: '',
    statusCode: 200,
    data: {},
  }

  async create(createUnitDto: CreateUnitDto) {
    this.resp.data = {}
    this.resp.error = false
    try {
      this.resp.statusCode = 200;

      const createdUnit = await this.prisma.unit.create({
        data: {
          name: createUnitDto.name,
          origin: createUnitDto.origin,
          plate_number: createUnitDto.plate_number,
          vehicle_fleet: createUnitDto.vehicle_fleet,
          km_traveled: createUnitDto.km_traveled,
          year: createUnitDto.year,
          seats: createUnitDto.seats,
          entry_at: createUnitDto.entry_at,
          axles: createUnitDto.axles,
          brand: createUnitDto.brand,
          model: createUnitDto.model,
          unit_serial_number: createUnitDto.unit_serial_number,
          unit_chassis_number: createUnitDto.unit_chassis_number,
          engine_serial_number: createUnitDto.engine_serial_number,
          insured_seats: createUnitDto.insured_seats,
          tuc: createUnitDto.tuc,
          manufacturing_year: createUnitDto.manufacturing_year,
          chassis_number: createUnitDto.chassis_number,
          contract_expires_at: createUnitDto.contract_expires_at,
        }
      })

      this.resp.message = "Unidad creada";
      this.resp.data = createdUnit;

    } catch (e) {
      this.resp.error = true
      this.resp.statusCode = 500;
      this.resp.message = JSON.stringify(e);
    }
    return this.resp;
  }

  async findAll(paginationDto: PaginationDto) {
    try {
      this.resp.data = {}
      this.resp.error = false;
      this.resp.statusCode = 200;
      var {
        page = 1,
        limit = 10,
        order = "desc",
        sort = "id",
        filter = "[]",

      } = paginationDto;

      const objectFilter = await this.globalFunctions.getObjectFilterGrid(
        sort,
        order,
        page,
        limit,
        filter
      );

      const offset = await this.globalFunctions.getOffsetByPage(page, limit);
      const data = await this.prisma.unit.aggregate({
        _count: {
          id: true,
        },
        where: {
          deleted_at: null,
          AND: objectFilter.contains
        },
      });
      const { _count } = data;
      const pages = await this.globalFunctions.getCantPages(_count.id, limit);
      const responseFilter = await this.globalFunctions.getResponseFilter(
        limit,
        order,
        page,
        sort,
        pages,
        _count.id
      );

      const rows = await this.prisma.unit.findMany({
        select: {
          id:true,
          name: true,
          origin: true,
          plate_number: true,
          vehicle_fleet: true,
          km_traveled: true,
          year: true,
          seats: true,
          entry_at: true,
          axles: true,
          brand: true,
          model: true,
          unit_serial_number: true,
          unit_chassis_number: true,
          engine_serial_number: true,
          insured_seats: true,
          tuc: true,
          manufacturing_year: true,
          chassis_number: true,
          contract_expires_at: true,
          isActive:true,
        },
        where: {
          deleted_at: null,
          isActive:true,
          AND: objectFilter.contains,

        },
        skip: offset,
        take: objectFilter.cant,
        orderBy: objectFilter.order,
      });
      this.resp.data = {
        rows, responseFilter
      }
    } catch (e) {
      console.log({ error: e })
      this.resp.error = true;
      this.resp.message = JSON.stringify(e);
      this.resp.statusCode = 400;
    }
    return this.resp
  }

  async findOne(id: number) {
    try {
      this.resp.data = {}
      this.resp.error = false;
      this.resp.statusCode = 200;

      const unit = await this.prisma.unit.findUnique({
        where: {
          id: id
        }
      });

      if (!unit) {
        throw new BadRequestException('Unidad no existente');
      }

      this.resp.message = "";
      this.resp.data = unit;
    } catch (e) {
      this.resp.statusCode = 500;
      this.resp.error = true;
      this.resp.message = JSON.stringify(e);
    }
    return this.resp;
  }

  async update(id: number, updateUnitDto: UpdateUnitDto) {
    try {
      this.resp.data = {}
      this.resp.error = false;
      this.resp.statusCode = 200;
      const unitFind = await this.prisma.unit.findUnique({
        where: {
          id: id
        }
      });
      if (!unitFind)
        throw new BadRequestException('Unidad no existente');

      const updatedUnit = await this.prisma.unit.update({
        where: {
          id: id
        },
        data: {
          name: updateUnitDto.name,
          origin: updateUnitDto.origin,
          plate_number: updateUnitDto.plate_number,
          vehicle_fleet: updateUnitDto.vehicle_fleet,
          km_traveled: updateUnitDto.km_traveled,
          year: updateUnitDto.year,
          seats: updateUnitDto.seats,
          entry_at: updateUnitDto.entry_at,
          axles: updateUnitDto.axles,
          brand: updateUnitDto.brand,
          model: updateUnitDto.model,
          unit_serial_number: updateUnitDto.unit_serial_number,
          unit_chassis_number: updateUnitDto.unit_chassis_number,
          engine_serial_number: updateUnitDto.engine_serial_number,
          insured_seats: updateUnitDto.insured_seats,
          tuc: updateUnitDto.tuc,
          manufacturing_year: updateUnitDto.manufacturing_year,
          chassis_number: updateUnitDto.chassis_number,
          contract_expires_at: updateUnitDto.contract_expires_at,
          updated_at: new Date()
        }
      });
      this.resp.message = "Unidad actualizada";
      this.resp.data = updatedUnit;
    } catch (e) {
      this.resp.error = true;
      this.resp.statusCode = 500;
      this.resp.message = JSON.stringify(e);
    }
    return this.resp;
  }

  async remove(id: number) {
    try {
      this.resp.data = {}
      this.resp.error = false;
      this.resp.statusCode = 200;
      await this.prisma.unit.update({
        where: {
          id: id
        },
        data: {
          deleted_at: new Date()
        }
      });
      this.resp.message = "Unidad eliminada";
    } catch (e) {
      this.resp.statusCode = 500;
      this.resp.error = true;
      this.resp.message = JSON.stringify(e);
    }
    return this.resp;
  }




}