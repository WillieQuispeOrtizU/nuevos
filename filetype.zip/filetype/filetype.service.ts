import { BadRequestException, Injectable } from '@nestjs/common';
import { CreateFiletypeDto } from './dto/create-filetype.dto';
import { UpdateFiletypeDto } from './dto/update-filetype.dto';
import { PrismaService } from 'src/prisma.service';
import { GlobalFunctions } from 'src/common/functions/global-function';
import { ResponseScheme } from 'src/common/interfaces/response.interface';
import { PaginationDto } from 'src/common/dto/pagination.interface';

@Injectable()
export class FiletypeService {

  constructor(
    private prisma: PrismaService,
    private readonly globalFunctions: GlobalFunctions
  ) { }

  private resp: ResponseScheme = {
    error: false,
    message: '',
    statusCode: 200,
    data: {},
  };

  async create(createFiletypeDto: CreateFiletypeDto) {
    this.resp.data = {};
    this.resp.error = false;
    try {
      const created = await this.prisma.filetype.create({
        data: {
          name: createFiletypeDto.name,
          color: createFiletypeDto.color,
        },
      });
      this.resp.message = 'Tipo de documento creado';
      this.resp.data = created;
    } catch (e) {
      this.resp.error = true;
      this.resp.statusCode = 500;
      this.resp.message = JSON.stringify(e);
    }
    return this.resp;
  }

  async findAll(paginationDto: PaginationDto) {
    try {
      this.resp.data = {};
      this.resp.error = false;
      this.resp.statusCode = 200;

      const {
        page = 1,
        limit = 10,
        order = 'desc',
        sort = 'id',
        filter = '[]',
      } = paginationDto;

      const objectFilter = await this.globalFunctions.getObjectFilterGrid(
        sort,
        order,
        page,
        limit,
        filter,
      );

      const offset = await this.globalFunctions.getOffsetByPage(page, limit);

      // Contar cuántos hay
      const data = await this.prisma.filetype.aggregate({
        _count: {
          id: true,
        },
        where: {
          deleted_at: null,
          AND: objectFilter.contains,
        },
      });

      const { _count } = data;
      const pages = await this.globalFunctions.getCantPages(_count.id, limit);
      const responseFilter = await this.globalFunctions.getResponseFilter(
        limit,
        order,
        page,
        sort,
        pages,
        _count.id,
      );

      // Obtener registros con paginación
      const rows = await this.prisma.filetype.findMany({
        select: {
          id: true,
          name: true,
          color: true,
          created_at: true,
          updated_at: true,
          isActive: true

        },
        where: {
          deleted_at: null,
          AND: objectFilter.contains,
        },
        skip: offset,
        take: objectFilter.cant,
        orderBy: objectFilter.order,
      });

      this.resp.message = 'Tipos de documentos encontrados';
      this.resp.data = {
        rows,
        responseFilter,
      };
    } catch (e) {
      console.log({ error: e });
      this.resp.error = true;
      this.resp.message = JSON.stringify(e);
      this.resp.statusCode = 400;
    }

    return this.resp;
  }

  async findOne(id: number) {
    try {
      this.resp.data = {};
      this.resp.error = false;
      this.resp.statusCode = 200;

      const filetype = await this.prisma.filetype.findUnique({
        where: { id },
      });

      if (!filetype || filetype.deleted_at !== null) {
        throw new BadRequestException('Tipo de documento no existente');
      }

      this.resp.message = 'Tipo de documento encontrado';
      this.resp.data = filetype;
    } catch (e) {
      this.resp.statusCode = 500;
      this.resp.error = true;
      this.resp.message = JSON.stringify(e);
    }
    return this.resp;
  }

  async update(id: number, updateFiletypeDto: UpdateFiletypeDto) {
    try {
      this.resp.data = {};
      this.resp.error = false;
      this.resp.statusCode = 200;

      const filetype = await this.prisma.filetype.findUnique({ where: { id } });

      if (!filetype || filetype.deleted_at !== null) {
        throw new BadRequestException('Tipo de documento no existente');
      }

      const updated = await this.prisma.filetype.update({
        where: { id },
        data: {
          name: updateFiletypeDto.name,
          color: updateFiletypeDto.color,
          updated_at: new Date(),
          isActive: updateFiletypeDto.isActive
        },
      });

      this.resp.message = 'Tipo de documento actualizado';
      this.resp.data = updated;
    } catch (e) {
      this.resp.error = true;
      this.resp.statusCode = 500;
      this.resp.message = JSON.stringify(e);
    }
    return this.resp;
  }

  async remove(id: number) {
    try {
      this.resp.data = {};
      this.resp.error = false;
      this.resp.statusCode = 200;

      await this.prisma.filetype.update({
        where: { id },
        data: {
          deleted_at: new Date(),
        },
      });

      this.resp.message = 'Tipo de documento eliminado';
    } catch (e) {
      this.resp.statusCode = 500;
      this.resp.error = true;
      this.resp.message = JSON.stringify(e);
    }
    return this.resp;
  }
}
