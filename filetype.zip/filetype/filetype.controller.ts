import { Controller, Get, Post, Body, Patch, Param, Delete, Query } from '@nestjs/common';
import { FiletypeService } from './filetype.service';
import { CreateFiletypeDto } from './dto/create-filetype.dto';
import { UpdateFiletypeDto } from './dto/update-filetype.dto';
import { PaginationDto } from 'src/common/dto/pagination.interface';

@Controller('filetype')
export class FiletypeController {
  constructor(private readonly filetypeService: FiletypeService) { }

  @Post()
  create(@Body() createFileTypeDto: CreateFiletypeDto) {
    return this.filetypeService.create(createFileTypeDto);
  }

  @Get()
  findAll(@Query() paginationDto: PaginationDto) {
    return this.filetypeService.findAll(paginationDto);
  }
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.filetypeService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateFiletypeDto: UpdateFiletypeDto) {
    return this.filetypeService.update(+id, updateFiletypeDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.filetypeService.remove(+id);
  }

}
