import { IsNumber, IsOptional, IsString } from "class-validator";

export class CreateFiletypeDto {

        @IsString()
        name: string;

        @IsOptional()
        @IsString()
        color: string;

        @IsOptional()
        @IsNumber()
        isActive: number;

}

