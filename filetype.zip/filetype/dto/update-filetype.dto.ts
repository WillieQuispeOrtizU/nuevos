import { PartialType } from '@nestjs/mapped-types';
import { CreateFiletypeDto } from './create-filetype.dto';

export class UpdateFiletypeDto extends PartialType(CreateFiletypeDto) {}
